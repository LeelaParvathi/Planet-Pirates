/*
  # Add cancellation reason to bookings

  1. Changes
    - Add `cancel_reason` column to bookings table for storing cancellation reasons
    - Add check constraint to ensure cancel_reason is provided when status is 'cancelled'
    - Update RLS policies to allow users to update their own bookings
*/

-- Add cancel_reason column
ALTER TABLE bookings 
ADD COLUMN cancel_reason text;

-- Add check constraint to ensure cancel_reason is provided when status is 'cancelled'
ALTER TABLE bookings
ADD CONSTRAINT valid_cancellation 
CHECK (
  (status != 'cancelled') OR 
  (status = 'cancelled' AND cancel_reason IS NOT NULL)
);

-- Update RLS policy for bookings to allow cancellation
CREATE POLICY "Users can update their own bookings"
  ON bookings FOR UPDATE
  TO authenticated
  USING (auth.uid() = passenger_id)
  WITH CHECK (auth.uid() = passenger_id);