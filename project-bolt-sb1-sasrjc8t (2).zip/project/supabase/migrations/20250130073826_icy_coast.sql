/*
  # Initial Schema Setup for Carpool Application

  1. New Tables
    - users (handled by Supabase Auth)
    - rides
      - id (uuid, primary key)
      - driver_id (references auth.users)
      - start_location (text)
      - end_location (text)
      - departure_time (timestamptz)
      - price (numeric)
      - available_seats (int)
      - created_at (timestamptz)
    - bookings
      - id (uuid, primary key)
      - ride_id (references rides)
      - passenger_id (references auth.users)
      - status (text)
      - created_at (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for CRUD operations
*/

-- Create rides table
CREATE TABLE rides (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  driver_id uuid REFERENCES auth.users NOT NULL,
  start_location text NOT NULL,
  end_location text NOT NULL,
  departure_time timestamptz NOT NULL,
  price numeric NOT NULL CHECK (price >= 0),
  available_seats int NOT NULL CHECK (available_seats > 0),
  created_at timestamptz DEFAULT now(),
  CONSTRAINT valid_locations CHECK (start_location <> end_location)
);

-- Create bookings table
CREATE TABLE bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ride_id uuid REFERENCES rides NOT NULL,
  passenger_id uuid REFERENCES auth.users NOT NULL,
  status text NOT NULL CHECK (status IN ('pending', 'confirmed', 'cancelled')),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE rides ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;

-- Policies for rides table
CREATE POLICY "Anyone can view rides"
  ON rides FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can create their own rides"
  ON rides FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = driver_id);

CREATE POLICY "Drivers can update their own rides"
  ON rides FOR UPDATE
  TO authenticated
  USING (auth.uid() = driver_id)
  WITH CHECK (auth.uid() = driver_id);

-- Policies for bookings table
CREATE POLICY "Users can view their own bookings and bookings for their rides"
  ON bookings FOR SELECT
  TO authenticated
  USING (
    auth.uid() = passenger_id OR 
    auth.uid() IN (
      SELECT driver_id FROM rides WHERE id = ride_id
    )
  );

CREATE POLICY "Users can create their own bookings"
  ON bookings FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = passenger_id);

CREATE POLICY "Users can update their own bookings"
  ON bookings FOR UPDATE
  TO authenticated
  USING (auth.uid() = passenger_id)
  WITH CHECK (auth.uid() = passenger_id);