import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { CheckCircle, Calendar } from 'lucide-react';

const BookingConfirmation = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { rideId } = location.state || {};

  return (
    <div className="min-h-screen bg-[#F5F5F5] flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white p-8 shadow-lg">
        <div className="text-center mb-8">
          <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
          <h1 className="text-3xl font-bold text-black mb-2">Booking Confirmed!</h1>
          <p className="text-gray-600">Your ride has been successfully booked.</p>
        </div>

        <div className="space-y-6">
          <div className="flex justify-between items-center p-4 bg-gray-50">
            <div className="flex items-center space-x-2">
              <Calendar className="w-5 h-5 text-[#0081A7]" />
              <span className="font-bold text-black">Booking ID</span>
            </div>
            <span className="text-black">{rideId}</span>
          </div>

          <div className="space-y-4">
            <button
              onClick={() => navigate('/booking-history')}
              className="w-full bg-[#0081A7] text-white font-bold py-3 transition-transform transform hover:translate-y-[-2px]"
            >
              View My Bookings
            </button>
            
            <button
              onClick={() => navigate('/')}
              className="w-full bg-white text-black font-bold py-3 border-2 border-black hover:bg-gray-50 transition-colors"
            >
              Book Another Ride
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookingConfirmation;