import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Clock, ArrowRight, User, DollarSign, Filter } from 'lucide-react';
import RideDetailsModal from '../components/RideDetailsModal';

const mockRides = [
  {
    id: 1,
    price: 25,
    start: 'San Francisco',
    destination: 'Los Angeles',
    startTime: '08:00',
    endTime: '14:00',
    driver: {
      name: 'John Doe',
      rating: 4.8,
      image: 'https://images.unsplash.com/photo-1633332755192-727a05c4013d?auto=format&fit=crop&w=100&h=100'
    },
    availableSeats: 3
  },
  // Add more mock rides...
];

const RideOptions = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [selectedRide, setSelectedRide] = useState(null);
  const [showFilters, setShowFilters] = useState(false);
  const [sortBy, setSortBy] = useState('price');
  const searchData = location.state;

  const handleBooking = (rideId: number) => {
    // Handle booking logic
    navigate('/booking-confirmation', { state: { rideId } });
  };

  return (
    <div className="min-h-screen bg-[#F5F5F5] p-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-4xl font-bold text-black">Available Rides</h1>
          
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center space-x-2 px-4 py-2 border-2 border-black hover:bg-gray-100"
          >
            <Filter className="w-5 h-5" />
            <span className="font-bold">Filters</span>
          </button>
        </div>

        {showFilters && (
          <div className="bg-white p-6 mb-6 shadow-lg">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label className="block text-sm font-bold text-black mb-2">Sort By</label>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="w-full px-4 py-2 border-2 border-black focus:border-[#0081A7] outline-none text-black font-bold"
                >
                  <option value="price">Price</option>
                  <option value="departure">Departure Time</option>
                  <option value="duration">Duration</option>
                </select>
              </div>
              
              {/* Add more filters */}
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {mockRides.map((ride) => (
            <div
              key={ride.id}
              className="bg-white p-6 shadow-lg cursor-pointer transform transition-transform hover:translate-y-[-4px]"
              onClick={() => setSelectedRide(ride)}
            >
              <div className="flex justify-between items-start mb-4">
                <div>
                  <p className="text-2xl font-bold text-[#0081A7]">${ride.price}</p>
                  <div className="flex items-center space-x-2 text-gray-600">
                    <Clock className="w-4 h-4" />
                    <span>{ride.startTime} - {ride.endTime}</span>
                  </div>
                </div>
                
                <div className="flex items-center space-x-1 text-black">
                  <User className="w-4 h-4" />
                  <span className="font-bold">{ride.availableSeats}</span>
                </div>
              </div>

              <div className="space-y-2 mb-4">
                <p className="font-bold text-black">{ride.start}</p>
                <div className="flex items-center space-x-2">
                  <div className="flex-1 border-t-2 border-dashed border-gray-300"></div>
                  <ArrowRight className="w-4 h-4 text-gray-400" />
                </div>
                <p className="font-bold text-black">{ride.destination}</p>
              </div>

              <div className="flex items-center space-x-3">
                <img
                  src={ride.driver.image}
                  alt={ride.driver.name}
                  className="w-10 h-10 rounded-full"
                />
                <div>
                  <p className="font-bold text-black">{ride.driver.name}</p>
                  <p className="text-sm text-gray-600">★ {ride.driver.rating}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {selectedRide && (
        <RideDetailsModal
          ride={selectedRide}
          onClose={() => setSelectedRide(null)}
          onBook={handleBooking}
        />
      )}
    </div>
  );
};

export default RideOptions;