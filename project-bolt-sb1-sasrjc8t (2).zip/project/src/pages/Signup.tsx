import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Car } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const Signup = () => {
  const navigate = useNavigate();
  const { signup } = useAuth();
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: ''
  });
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const validatePassword = (password: string) => {
    if (password.length < 6) {
      return 'Password must be at least 6 characters long';
    }
    return '';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Validate password
    const passwordError = validatePassword(formData.password);
    if (passwordError) {
      setError(passwordError);
      return;
    }

    setIsLoading(true);
    try {
      await signup(formData);
      navigate('/login');
    } catch (err: any) {
      if (err.message) {
        setError(err.message);
      } else {
        setError('An error occurred during signup');
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F5F5] flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="bg-white p-8 shadow-lg relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-[#F4D35E]" />
          
          <div className="flex justify-center mb-8">
            <div className="animate-float">
              <Car className="w-12 h-12 text-[#F4D35E]" />
            </div>
          </div>

          <h2 className="text-3xl font-bold mb-6 text-black tracking-tight">Create Account</h2>
          
          {error && (
            <div className="mb-4 p-3 bg-red-100 text-red-700 rounded">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-bold text-black mb-2">Username</label>
              <input
                type="text"
                className="w-full px-4 py-2 border-2 border-black focus:border-[#F4D35E] outline-none text-black font-bold transition-colors"
                value={formData.username}
                onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                required
                disabled={isLoading}
                minLength={3}
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-black mb-2">Email</label>
              <input
                type="email"
                className="w-full px-4 py-2 border-2 border-black focus:border-[#F4D35E] outline-none text-black font-bold transition-colors"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                required
                disabled={isLoading}
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-black mb-2">Password</label>
              <input
                type="password"
                className="w-full px-4 py-2 border-2 border-black focus:border-[#F4D35E] outline-none text-black font-bold transition-colors"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                required
                disabled={isLoading}
                minLength={6}
              />
              <p className="mt-1 text-sm text-gray-600">Must be at least 6 characters long</p>
            </div>

            <button
              type="submit"
              className={`w-full bg-[#F4D35E] text-black font-bold py-3 transition-all transform hover:translate-y-[-2px] ${
                isLoading ? 'opacity-70 cursor-not-allowed' : ''
              }`}
              disabled={isLoading}
            >
              {isLoading ? 'Creating Account...' : 'Sign Up'}
            </button>
          </form>

          <p className="mt-6 text-center text-black">
            Already have an account?{' '}
            <Link to="/login" className="text-[#F4D35E] font-bold hover:underline">
              Sign in
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Signup;