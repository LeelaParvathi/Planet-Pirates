import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { createClient } from '@supabase/supabase-js';
import { Camera, Lock, Car as CarIcon, Save, Upload } from 'lucide-react';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL!,
  import.meta.env.VITE_SUPABASE_ANON_KEY!
);

interface CarDetails {
  model: string;
  number: string;
  color: string;
  year: string;
}

const Settings = () => {
  const { user } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState({ type: '', text: '' });
  
  // Password change state
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  // Car details state
  const [carDetails, setCarDetails] = useState<CarDetails>({
    model: '',
    number: '',
    color: '',
    year: ''
  });

  // Profile image state
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);

  useEffect(() => {
    if (user) {
      fetchProfileData();
    }
  }, [user]);

  const fetchProfileData = async () => {
    try {
      const { data: profile } = await supabase
        .from('profiles')
        .select('avatar_url, car_details')
        .eq('id', user.id)
        .single();

      if (profile) {
        setAvatarUrl(profile.avatar_url);
        if (profile.car_details) {
          setCarDetails(profile.car_details);
        }
      }
    } catch (error) {
      console.error('Error fetching profile:', error);
    }
  };

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setMessage({ type: '', text: '' });

    if (passwordData.newPassword !== passwordData.confirmPassword) {
      setMessage({ type: 'error', text: 'New passwords do not match' });
      setIsLoading(false);
      return;
    }

    try {
      const { error } = await supabase.auth.updateUser({
        password: passwordData.newPassword
      });

      if (error) throw error;

      setMessage({ type: 'success', text: 'Password updated successfully' });
      setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
    } catch (error: any) {
      setMessage({ type: 'error', text: error.message });
    } finally {
      setIsLoading(false);
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsLoading(true);
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${user.id}-${Math.random()}.${fileExt}`;
      const filePath = `avatars/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('avatars')
        .getPublicUrl(filePath);

      const { error: updateError } = await supabase
        .from('profiles')
        .update({ avatar_url: publicUrl })
        .eq('id', user.id);

      if (updateError) throw updateError;

      setAvatarUrl(publicUrl);
      setMessage({ type: 'success', text: 'Profile picture updated successfully' });
    } catch (error: any) {
      setMessage({ type: 'error', text: error.message });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCarDetailsUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ car_details: carDetails })
        .eq('id', user.id);

      if (error) throw error;

      setMessage({ type: 'success', text: 'Car details updated successfully' });
    } catch (error: any) {
      setMessage({ type: 'error', text: error.message });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0A192F] text-[#F8F8F8] p-6">
      <div className="max-w-4xl mx-auto space-y-8">
        <h1 className="text-4xl font-bold mb-8">Profile Settings</h1>

        {message.text && (
          <div className={`p-4 rounded ${
            message.type === 'success' ? 'bg-[#2ECC71]/20 text-[#2ECC71]' : 'bg-red-500/20 text-red-500'
          }`}>
            {message.text}
          </div>
        )}

        {/* Profile Picture Section */}
        <div className="bg-[#0A192F] p-6 rounded-lg border border-[#4169E1]/30">
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
            <Camera className="w-6 h-6 text-[#FFD700]" />
            Profile Picture
          </h2>
          
          <div className="flex items-center space-x-6">
            <div className="relative w-32 h-32">
              <img
                src={avatarUrl || 'https://via.placeholder.com/128'}
                alt="Profile"
                className="w-full h-full object-cover rounded-lg"
              />
            </div>
            
            <div>
              <label className="cursor-pointer">
                <div className="flex items-center gap-2 px-4 py-2 bg-[#4169E1] hover:bg-[#4169E1]/80 rounded transition-colors">
                  <Upload className="w-5 h-5" />
                  <span>Upload New Picture</span>
                </div>
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleImageUpload}
                  disabled={isLoading}
                />
              </label>
            </div>
          </div>
        </div>

        {/* Password Change Section */}
        <div className="bg-[#0A192F] p-6 rounded-lg border border-[#4169E1]/30">
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
            <Lock className="w-6 h-6 text-[#FFD700]" />
            Change Password
          </h2>
          
          <form onSubmit={handlePasswordChange} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Current Password</label>
              <input
                type="password"
                value={passwordData.currentPassword}
                onChange={(e) => setPasswordData({ ...passwordData, currentPassword: e.target.value })}
                className="w-full px-4 py-2 bg-[#0A192F] border border-[#4169E1]/50 rounded focus:border-[#FFD700] outline-none"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-2">New Password</label>
              <input
                type="password"
                value={passwordData.newPassword}
                onChange={(e) => setPasswordData({ ...passwordData, newPassword: e.target.value })}
                className="w-full px-4 py-2 bg-[#0A192F] border border-[#4169E1]/50 rounded focus:border-[#FFD700] outline-none"
                required
                minLength={6}
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-2">Confirm New Password</label>
              <input
                type="password"
                value={passwordData.confirmPassword}
                onChange={(e) => setPasswordData({ ...passwordData, confirmPassword: e.target.value })}
                className="w-full px-4 py-2 bg-[#0A192F] border border-[#4169E1]/50 rounded focus:border-[#FFD700] outline-none"
                required
                minLength={6}
              />
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full px-4 py-2 bg-[#2ECC71] hover:bg-[#2ECC71]/80 text-white font-medium rounded transition-colors"
            >
              Update Password
            </button>
          </form>
        </div>

        {/* Car Details Section */}
        <div className="bg-[#0A192F] p-6 rounded-lg border border-[#4169E1]/30">
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
            <CarIcon className="w-6 h-6 text-[#FFD700]" />
            Car Details
          </h2>
          
          <form onSubmit={handleCarDetailsUpdate} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">Car Model</label>
                <input
                  type="text"
                  value={carDetails.model}
                  onChange={(e) => setCarDetails({ ...carDetails, model: e.target.value })}
                  className="w-full px-4 py-2 bg-[#0A192F] border border-[#4169E1]/50 rounded focus:border-[#FFD700] outline-none"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Car Number</label>
                <input
                  type="text"
                  value={carDetails.number}
                  onChange={(e) => setCarDetails({ ...carDetails, number: e.target.value })}
                  className="w-full px-4 py-2 bg-[#0A192F] border border-[#4169E1]/50 rounded focus:border-[#FFD700] outline-none"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Car Color</label>
                <input
                  type="text"
                  value={carDetails.color}
                  onChange={(e) => setCarDetails({ ...carDetails, color: e.target.value })}
                  className="w-full px-4 py-2 bg-[#0A192F] border border-[#4169E1]/50 rounded focus:border-[#FFD700] outline-none"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Manufacturing Year</label>
                <input
                  type="text"
                  value={carDetails.year}
                  onChange={(e) => setCarDetails({ ...carDetails, year: e.target.value })}
                  className="w-full px-4 py-2 bg-[#0A192F] border border-[#4169E1]/50 rounded focus:border-[#FFD700] outline-none"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full px-4 py-2 bg-[#2ECC71] hover:bg-[#2ECC71]/80 text-white font-medium rounded transition-colors flex items-center justify-center gap-2"
            >
              <Save className="w-5 h-5" />
              Save Car Details
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Settings;