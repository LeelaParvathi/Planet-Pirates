import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeftRight, Plus, Minus } from 'lucide-react';

const Home = () => {
  const navigate = useNavigate();
  const [searchData, setSearchData] = useState({
    start: '',
    destination: '',
    date: '',
    passengers: 1
  });

  const handleSwap = () => {
    setSearchData(prev => ({
      ...prev,
      start: prev.destination,
      destination: prev.start
    }));
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    navigate('/rides', { state: searchData });
  };

  return (
    <div className="min-h-screen bg-[#F5F5F5] p-4">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-bold text-black mb-8">Find Your Ride</h1>
        
        <div className="bg-white p-8 shadow-lg">
          <form onSubmit={handleSearch} className="space-y-6">
            <div className="relative">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-bold text-black mb-2">Starting Location</label>
                  <input
                    type="text"
                    className="w-full px-4 py-2 border-2 border-black focus:border-[#0081A7] outline-none text-black font-bold"
                    value={searchData.start}
                    onChange={(e) => setSearchData({ ...searchData, start: e.target.value })}
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-bold text-black mb-2">Destination</label>
                  <input
                    type="text"
                    className="w-full px-4 py-2 border-2 border-black focus:border-[#0081A7] outline-none text-black font-bold"
                    value={searchData.destination}
                    onChange={(e) => setSearchData({ ...searchData, destination: e.target.value })}
                    required
                  />
                </div>
              </div>
              
              <button
                type="button"
                onClick={handleSwap}
                className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 md:block hidden bg-white p-2 rounded-full shadow-lg hover:shadow-xl transition-shadow"
              >
                <ArrowLeftRight className="w-6 h-6 text-[#0081A7]" />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-bold text-black mb-2">Date</label>
                <input
                  type="date"
                  className="w-full px-4 py-2 border-2 border-black focus:border-[#0081A7] outline-none text-black font-bold"
                  value={searchData.date}
                  onChange={(e) => setSearchData({ ...searchData, date: e.target.value })}
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-bold text-black mb-2">Passengers</label>
                <div className="flex items-center space-x-4">
                  <button
                    type="button"
                    onClick={() => setSearchData(prev => ({
                      ...prev,
                      passengers: Math.max(1, prev.passengers - 1)
                    }))}
                    className="p-2 border-2 border-black hover:bg-gray-100"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  
                  <span className="text-xl font-bold text-black w-12 text-center">
                    {searchData.passengers}
                  </span>
                  
                  <button
                    type="button"
                    onClick={() => setSearchData(prev => ({
                      ...prev,
                      passengers: Math.min(8, prev.passengers + 1)
                    }))}
                    className="p-2 border-2 border-black hover:bg-gray-100"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-[#0081A7] text-white font-bold py-3 transition-transform transform hover:translate-y-[-2px]"
            >
              Search Rides
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Home;