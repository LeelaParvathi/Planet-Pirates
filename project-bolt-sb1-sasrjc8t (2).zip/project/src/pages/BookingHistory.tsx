import React, { useState, useEffect } from 'react';
import { Calendar, Clock, MapPin, X, AlertCircle } from 'lucide-react';
import { createClient } from '@supabase/supabase-js';
import { useAuth } from '../context/AuthContext';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL!,
  import.meta.env.VITE_SUPABASE_ANON_KEY!
);

interface Booking {
  id: number;
  status: string;
  date: string;
  time: string;
  from: string;
  to: string;
  price: number;
  driver: string;
  cancel_reason?: string;
}

const BookingHistory = () => {
  const { user } = useAuth();
  const [selectedFilter, setSelectedFilter] = useState('all');
  const [cancelReason, setCancelReason] = useState('');
  const [bookingToCancel, setBookingToCancel] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchBookings();
  }, [user]);

  const fetchBookings = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('bookings')
        .select(`
          id,
          status,
          rides (
            departure_time,
            start_location,
            end_location,
            price,
            driver:driver_id (
              email
            )
          )
        `)
        .eq('passenger_id', user.id);

      if (error) throw error;

      const formattedBookings = data.map(booking => ({
        id: booking.id,
        status: booking.status,
        date: new Date(booking.rides.departure_time).toLocaleDateString(),
        time: new Date(booking.rides.departure_time).toLocaleTimeString(),
        from: booking.rides.start_location,
        to: booking.rides.end_location,
        price: booking.rides.price,
        driver: booking.rides.driver.email
      }));

      setBookings(formattedBookings);
    } catch (err: any) {
      setError(err.message);
      console.error('Error fetching bookings:', err);
    }
  };

  const handleCancelBooking = async (bookingId: number) => {
    if (!cancelReason.trim()) {
      setError('Please provide a reason for cancellation');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const { error } = await supabase
        .from('bookings')
        .update({
          status: 'cancelled',
          cancel_reason: cancelReason
        })
        .eq('id', bookingId)
        .eq('passenger_id', user?.id);

      if (error) throw error;

      setBookingToCancel(null);
      setCancelReason('');
      await fetchBookings(); // Refresh bookings list
    } catch (err: any) {
      setError(err.message);
      console.error('Error cancelling booking:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const filteredBookings = bookings.filter(booking => 
    selectedFilter === 'all' || booking.status === selectedFilter
  );

  return (
    <div className="min-h-screen bg-[#0A192F] text-[#F8F8F8] p-4">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-bold text-[#FFD700] mb-8">My Bookings</h1>

        {error && (
          <div className="mb-6 p-4 bg-red-500/20 text-red-500 rounded-lg">
            {error}
          </div>
        )}

        <div className="bg-[#0A192F] p-6 shadow-lg border border-[#4169E1]/30 rounded-lg mb-6">
          <div className="flex space-x-4">
            {['all', 'upcoming', 'completed', 'cancelled'].map((filter) => (
              <button
                key={filter}
                onClick={() => setSelectedFilter(filter)}
                className={`px-4 py-2 font-bold capitalize rounded transition-colors ${
                  selectedFilter === filter
                    ? 'bg-[#2ECC71] text-white'
                    : 'bg-[#0A192F] text-[#F8F8F8] border border-[#4169E1] hover:bg-[#4169E1]/20'
                }`}
              >
                {filter}
              </button>
            ))}
          </div>
        </div>

        {filteredBookings.length === 0 ? (
          <div className="text-center py-12 bg-[#0A192F] rounded-lg border border-[#4169E1]/30">
            <p className="text-[#F8F8F8]/60">No bookings found</p>
          </div>
        ) : (
          <div className="space-y-6">
            {filteredBookings.map((booking) => (
              <div key={booking.id} className="bg-[#0A192F] p-6 shadow-lg border border-[#4169E1]/30 rounded-lg">
                <div className="flex justify-between items-start mb-6">
                  <div>
                    <div className="flex items-center space-x-2 mb-2">
                      <Calendar className="w-5 h-5 text-[#FFD700]" />
                      <span className="font-bold text-[#F8F8F8]">{booking.date}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Clock className="w-5 h-5 text-[#FFD700]" />
                      <span className="text-[#F8F8F8]">{booking.time}</span>
                    </div>
                  </div>

                  <div className="flex items-center space-x-4">
                    <span className={`px-3 py-1 text-sm font-bold capitalize rounded ${
                      booking.status === 'upcoming' ? 'bg-[#4169E1]/20 text-[#4169E1]' :
                      booking.status === 'completed' ? 'bg-[#2ECC71]/20 text-[#2ECC71]' :
                      'bg-red-500/20 text-red-500'
                    }`}>
                      {booking.status}
                    </span>
                    
                    {booking.status === 'upcoming' && (
                      <button
                        onClick={() => setBookingToCancel(booking.id)}
                        className="p-2 hover:bg-red-500/20 text-red-500 rounded transition-colors"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    )}
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-start space-x-2">
                    <MapPin className="w-5 h-5 text-[#FFD700] mt-1" />
                    <div>
                      <p className="font-bold text-[#F8F8F8]">{booking.from}</p>
                      <div className="h-6 border-l-2 border-dashed border-[#4169E1] ml-2"></div>
                      <p className="font-bold text-[#F8F8F8]">{booking.to}</p>
                    </div>
                  </div>

                  <div className="flex justify-between items-center pt-4 border-t border-[#4169E1]/30">
                    <div>
                      <p className="text-sm text-[#F8F8F8]/60">Driver</p>
                      <p className="font-bold text-[#F8F8F8]">{booking.driver}</p>
                    </div>
                    <div>
                      <p className="text-sm text-[#F8F8F8]/60">Price</p>
                      <p className="text-xl font-bold text-[#FFD700]">₹{booking.price}</p>
                    </div>
                  </div>

                  {booking.cancel_reason && (
                    <div className="mt-4 p-4 bg-red-500/10 rounded-lg">
                      <p className="text-sm text-[#F8F8F8]/60">Cancellation Reason:</p>
                      <p className="text-[#F8F8F8]">{booking.cancel_reason}</p>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Cancellation Modal */}
      {bookingToCancel && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-[#0A192F] p-6 rounded-lg shadow-xl border border-[#4169E1]/30 max-w-md w-full">
            <h3 className="text-xl font-bold mb-4 text-[#F8F8F8]">Cancel Booking</h3>
            
            <div className="mb-4">
              <label className="block text-sm font-medium text-[#F8F8F8]/60 mb-2">
                Please provide a reason for cancellation
              </label>
              <textarea
                value={cancelReason}
                onChange={(e) => setCancelReason(e.target.value)}
                className="w-full px-4 py-2 bg-[#0A192F] border border-[#4169E1]/50 rounded focus:border-[#FFD700] outline-none text-[#F8F8F8]"
                rows={4}
                required
              />
            </div>

            <div className="flex space-x-4">
              <button
                onClick={() => {
                  setBookingToCancel(null);
                  setCancelReason('');
                  setError(null);
                }}
                className="flex-1 px-4 py-2 border border-[#4169E1] text-[#F8F8F8] rounded hover:bg-[#4169E1]/20 transition-colors"
                disabled={isLoading}
              >
                Cancel
              </button>
              <button
                onClick={() => handleCancelBooking(bookingToCancel)}
                className="flex-1 px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600 transition-colors flex items-center justify-center gap-2"
                disabled={isLoading}
              >
                {isLoading ? (
                  'Processing...'
                ) : (
                  <>
                    <AlertCircle className="w-5 h-5" />
                    Confirm Cancellation
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BookingHistory;