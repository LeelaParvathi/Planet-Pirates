import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Calendar, Clock, MapPin, DollarSign, Users } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL || '',
  import.meta.env.VITE_SUPABASE_ANON_KEY || ''
);

const OfferRide = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [rideData, setRideData] = useState({
    startLocation: '',
    endLocation: '',
    departureDate: '',
    departureTime: '',
    price: '',
    availableSeats: 1,
    description: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const { error } = await supabase.from('rides').insert({
        driver_id: user.id,
        start_location: rideData.startLocation,
        end_location: rideData.endLocation,
        departure_time: `${rideData.departureDate}T${rideData.departureTime}:00`,
        price: parseFloat(rideData.price),
        available_seats: rideData.availableSeats
      });

      if (error) throw error;
      navigate('/my-rides');
    } catch (error) {
      console.error('Error offering ride:', error);
    }
  };

  return (
    <div className="max-w-2xl mx-auto bg-white p-8 shadow-lg">
      <h1 className="text-3xl font-bold text-black mb-8">Offer a Ride</h1>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-bold text-black mb-2">
              <MapPin className="w-4 h-4 inline-block mr-2" />
              Starting Location
            </label>
            <input
              type="text"
              value={rideData.startLocation}
              onChange={(e) => setRideData({ ...rideData, startLocation: e.target.value })}
              className="w-full px-4 py-2 border-2 border-black focus:border-[#0081A7] outline-none"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-bold text-black mb-2">
              <MapPin className="w-4 h-4 inline-block mr-2" />
              Destination
            </label>
            <input
              type="text"
              value={rideData.endLocation}
              onChange={(e) => setRideData({ ...rideData, endLocation: e.target.value })}
              className="w-full px-4 py-2 border-2 border-black focus:border-[#0081A7] outline-none"
              required
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-bold text-black mb-2">
              <Calendar className="w-4 h-4 inline-block mr-2" />
              Departure Date
            </label>
            <input
              type="date"
              value={rideData.departureDate}
              onChange={(e) => setRideData({ ...rideData, departureDate: e.target.value })}
              className="w-full px-4 py-2 border-2 border-black focus:border-[#0081A7] outline-none"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-bold text-black mb-2">
              <Clock className="w-4 h-4 inline-block mr-2" />
              Departure Time
            </label>
            <input
              type="time"
              value={rideData.departureTime}
              onChange={(e) => setRideData({ ...rideData, departureTime: e.target.value })}
              className="w-full px-4 py-2 border-2 border-black focus:border-[#0081A7] outline-none"
              required
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-bold text-black mb-2">
              <DollarSign className="w-4 h-4 inline-block mr-2" />
              Price per Seat
            </label>
            <input
              type="number"
              min="0"
              step="0.01"
              value={rideData.price}
              onChange={(e) => setRideData({ ...rideData, price: e.target.value })}
              className="w-full px-4 py-2 border-2 border-black focus:border-[#0081A7] outline-none"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-bold text-black mb-2">
              <Users className="w-4 h-4 inline-block mr-2" />
              Available Seats
            </label>
            <input
              type="number"
              min="1"
              max="8"
              value={rideData.availableSeats}
              onChange={(e) => setRideData({ ...rideData, availableSeats: parseInt(e.target.value) })}
              className="w-full px-4 py-2 border-2 border-black focus:border-[#0081A7] outline-none"
              required
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-bold text-black mb-2">
            Additional Information
          </label>
          <textarea
            value={rideData.description}
            onChange={(e) => setRideData({ ...rideData, description: e.target.value })}
            className="w-full px-4 py-2 border-2 border-black focus:border-[#0081A7] outline-none h-32"
            placeholder="Add any additional details about the ride..."
          />
        </div>

        <button
          type="submit"
          className="w-full bg-[#0081A7] text-white font-bold py-3 transition-transform transform hover:translate-y-[-2px]"
        >
          Publish Ride
        </button>
      </form>
    </div>
  );
};

export default OfferRide;