import React, { useEffect, useState } from 'react';
import { createClient } from '@supabase/supabase-js';
import { useAuth } from '../context/AuthContext';
import { MapPin, Calendar, Users, DollarSign } from 'lucide-react';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL || '',
  import.meta.env.VITE_SUPABASE_ANON_KEY || ''
);

const MyRides = () => {
  const { user } = useAuth();
  const [rides, setRides] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchRides = async () => {
      try {
        const { data, error } = await supabase
          .from('rides')
          .select(`
            *,
            bookings (
              id,
              passenger_id,
              status
            )
          `)
          .eq('driver_id', user.id);

        if (error) throw error;
        setRides(data || []);
      } catch (error) {
        console.error('Error fetching rides:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchRides();
  }, [user.id]);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#0081A7]"></div>
      </div>
    );
  }

  return (
    <div>
      <h1 className="text-3xl font-bold text-black mb-8">My Rides</h1>

      {rides.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-gray-600 mb-4">You haven't offered any rides yet.</p>
          <button
            onClick={() => navigate('/offer-ride')}
            className="bg-[#0081A7] text-white px-6 py-2 font-bold hover:bg-[#006d8f] transition-colors"
          >
            Offer a Ride
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {rides.map((ride) => (
            <div key={ride.id} className="bg-white p-6 shadow-lg">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <div className="flex items-center space-x-2 mb-2">
                    <MapPin className="w-5 h-5 text-[#0081A7]" />
                    <span className="font-bold">{ride.start_location}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <MapPin className="w-5 h-5 text-[#0081A7]" />
                    <span className="font-bold">{ride.end_location}</span>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold text-[#0081A7]">
                    ${ride.price}
                  </p>
                  <p className="text-sm text-gray-600">per seat</p>
                </div>
              </div>

              <div className="space-y-3 mb-4">
                <div className="flex items-center space-x-2">
                  <Calendar className="w-4 h-4 text-gray-600" />
                  <span>{formatDate(ride.departure_time)}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Users className="w-4 h-4 text-gray-600" />
                  <span>{ride.available_seats} seats available</span>
                </div>
              </div>

              <div className="border-t pt-4">
                <h3 className="font-bold mb-2">Bookings</h3>
                {ride.bookings.length === 0 ? (
                  <p className="text-gray-600">No bookings yet</p>
                ) : (
                  <div className="space-y-2">
                    {ride.bookings.map((booking) => (
                      <div
                        key={booking.id}
                        className="flex items-center justify-between"
                      >
                        <span>{booking.passenger_id}</span>
                        <span className={`px-2 py-1 text-sm font-bold rounded ${
                          booking.status === 'confirmed'
                            ? 'bg-green-100 text-green-800'
                            : booking.status === 'pending'
                            ? 'bg-yellow-100 text-yellow-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {booking.status}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default MyRides;