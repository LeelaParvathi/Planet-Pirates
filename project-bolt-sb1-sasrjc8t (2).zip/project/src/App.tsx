import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Home from './pages/Home';
import RideOptions from './pages/RideOptions';
import BookingConfirmation from './pages/BookingConfirmation';
import BookingHistory from './pages/BookingHistory';
import OfferRide from './pages/OfferRide';
import MyRides from './pages/MyRides';
import Layout from './components/Layout';
import { AuthProvider, useAuth } from './context/AuthContext';

const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { isAuthenticated } = useAuth();
  return isAuthenticated ? children : <Navigate to="/login" />;
};

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/" element={
            <ProtectedRoute>
              <Layout>
                <Home />
              </Layout>
            </ProtectedRoute>
          } />
          <Route path="/rides" element={
            <ProtectedRoute>
              <Layout>
                <RideOptions />
              </Layout>
            </ProtectedRoute>
          } />
          <Route path="/offer-ride" element={
            <ProtectedRoute>
              <Layout>
                <OfferRide />
              </Layout>
            </ProtectedRoute>
          } />
          <Route path="/my-rides" element={
            <ProtectedRoute>
              <Layout>
                <MyRides />
              </Layout>
            </ProtectedRoute>
          } />
          <Route path="/booking-confirmation" element={
            <ProtectedRoute>
              <Layout>
                <BookingConfirmation />
              </Layout>
            </ProtectedRoute>
          } />
          <Route path="/booking-history" element={
            <ProtectedRoute>
              <Layout>
                <BookingHistory />
              </Layout>
            </ProtectedRoute>
          } />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App