import React from 'react';
import { X, MapPin, Clock, User, Star } from 'lucide-react';

interface RideDetailsModalProps {
  ride: any;
  onClose: () => void;
  onBook: (rideId: number) => void;
}

const RideDetailsModal: React.FC<RideDetailsModalProps> = ({ ride, onClose, onBook }) => {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-white w-full max-w-2xl rounded-none shadow-xl relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 hover:bg-gray-100"
        >
          <X className="w-6 h-6" />
        </button>

        <div className="p-8">
          <h2 className="text-3xl font-bold text-black mb-6">Ride Details</h2>

          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-6">
              <div>
                <div className="flex items-center space-x-2 mb-2">
                  <MapPin className="w-5 h-5 text-[#0081A7]" />
                  <span className="font-bold text-black">Pickup</span>
                </div>
                <p className="text-black">{ride.start}</p>
              </div>

              <div>
                <div className="flex items-center space-x-2 mb-2">
                  <MapPin className="w-5 h-5 text-[#0081A7]" />
                  <span className="font-bold text-black">Dropoff</span>
                </div>
                <p className="text-black">{ride.destination}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div>
                <div className="flex items-center space-x-2 mb-2">
                  <Clock className="w-5 h-5 text-[#0081A7]" />
                  <span className="font-bold text-black">Departure</span>
                </div>
                <p className="text-black">{ride.startTime}</p>
              </div>

              <div>
                <div className="flex items-center space-x-2 mb-2">
                  <Clock className="w-5 h-5 text-[#0081A7]" />
                  <span className="font-bold text-black">Arrival</span>
                </div>
                <p className="text-black">{ride.endTime}</p>
              </div>
            </div>

            <div className="border-t-2 border-gray-100 pt-6">
              <h3 className="text-xl font-bold text-black mb-4">Driver</h3>
              <div className="flex items-center space-x-4">
                <img
                  src={ride.driver.image}
                  alt={ride.driver.name}
                  className="w-16 h-16 rounded-full"
                />
                <div>
                  <p className="font-bold text-black">{ride.driver.name}</p>
                  <div className="flex items-center space-x-1">
                    <Star className="w-4 h-4 text-[#F4D35E] fill-current" />
                    <span className="text-black">{ride.driver.rating}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="border-t-2 border-gray-100 pt-6">
              <div className="flex justify-between items-center mb-6">
                <div>
                  <p className="text-sm text-gray-600">Price per seat</p>
                  <p className="text-3xl font-bold text-black">${ride.price}</p>
                </div>
                <div className="flex items-center space-x-2">
                  <User className="w-5 h-5 text-gray-600" />
                  <span className="font-bold text-black">{ride.availableSeats} seats available</span>
                </div>
              </div>

              <button
                onClick={() => onBook(ride.id)}
                className="w-full bg-[#0081A7] text-white font-bold py-3 transition-transform transform hover:translate-y-[-2px]"
              >
                Request to Book
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RideDetailsModal;