import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Car, Menu, X, LogOut, Settings, History, UserPlus, ChevronDown } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const [isProfileOpen, setIsProfileOpen] = React.useState(false);
  const navigate = useNavigate();
  const { logout, user } = useAuth();

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-[#F5F5F5]">
      <nav className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Car className="w-8 h-8 text-[#0081A7]" />
              <span className="ml-2 text-xl font-bold text-black">CarpoolConnect</span>
            </div>

            <div className="hidden md:flex items-center space-x-8">
              <button
                onClick={() => navigate('/')}
                className="text-black font-bold hover:text-[#0081A7]"
              >
                Find Rides
              </button>
              <div className="relative">
                <button
                  onClick={() => setIsProfileOpen(!isProfileOpen)}
                  className="flex items-center space-x-2 text-black font-bold hover:text-[#0081A7]"
                >
                  <span>Offer Rides</span>
                  <ChevronDown className="w-4 h-4" />
                </button>
                {isProfileOpen && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1">
                    <button
                      onClick={() => {
                        navigate('/offer-ride');
                        setIsProfileOpen(false);
                      }}
                      className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    >
                      Offer a New Ride
                    </button>
                    <button
                      onClick={() => {
                        navigate('/my-rides');
                        setIsProfileOpen(false);
                      }}
                      className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    >
                      My Offered Rides
                    </button>
                  </div>
                )}
              </div>
              <button
                onClick={() => navigate('/booking-history')}
                className="text-black font-bold hover:text-[#0081A7]"
              >
                My Bookings
              </button>
              <button
                onClick={() => navigate('/settings')}
                className="text-black font-bold hover:text-[#0081A7]"
              >
                Settings
              </button>
              <button
                onClick={handleLogout}
                className="bg-[#0081A7] text-white px-4 py-2 font-bold hover:bg-[#006d8f] transition-colors"
              >
                Sign Out
              </button>
            </div>

            <div className="md:hidden">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="text-black hover:text-[#0081A7]"
              >
                {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {isMenuOpen && (
          <div className="md:hidden border-t border-gray-200">
            <div className="px-2 pt-2 pb-3 space-y-1">
              <button
                onClick={() => {
                  navigate('/');
                  setIsMenuOpen(false);
                }}
                className="block w-full text-left px-3 py-2 text-black font-bold hover:bg-gray-100"
              >
                Find Rides
              </button>
              <button
                onClick={() => {
                  navigate('/offer-ride');
                  setIsMenuOpen(false);
                }}
                className="block w-full text-left px-3 py-2 text-black font-bold hover:bg-gray-100"
              >
                <UserPlus className="w-5 h-5 inline-block mr-2" />
                Offer a Ride
              </button>
              <button
                onClick={() => {
                  navigate('/my-rides');
                  setIsMenuOpen(false);
                }}
                className="block w-full text-left px-3 py-2 text-black font-bold hover:bg-gray-100"
              >
                <History className="w-5 h-5 inline-block mr-2" />
                My Offered Rides
              </button>
              <button
                onClick={() => {
                  navigate('/booking-history');
                  setIsMenuOpen(false);
                }}
                className="block w-full text-left px-3 py-2 text-black font-bold hover:bg-gray-100"
              >
                <History className="w-5 h-5 inline-block mr-2" />
                My Bookings
              </button>
              <button
                onClick={() => {
                  navigate('/settings');
                  setIsMenuOpen(false);
                }}
                className="block w-full text-left px-3 py-2 text-black font-bold hover:bg-gray-100"
              >
                <Settings className="w-5 h-5 inline-block mr-2" />
                Settings
              </button>
              <button
                onClick={handleLogout}
                className="block w-full text-left px-3 py-2 text-black font-bold hover:bg-gray-100"
              >
                <LogOut className="w-5 h-5 inline-block mr-2" />
                Sign Out
              </button>
            </div>
          </div>
        )}
      </nav>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {children}
      </main>
    </div>
  );
};

export default Layout;